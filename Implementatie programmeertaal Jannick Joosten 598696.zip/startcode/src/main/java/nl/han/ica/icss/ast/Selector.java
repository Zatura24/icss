package nl.han.ica.icss.ast;

public abstract class Selector extends ASTNode {
}
