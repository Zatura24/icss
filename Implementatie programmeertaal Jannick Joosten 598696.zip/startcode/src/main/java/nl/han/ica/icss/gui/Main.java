package nl.han.ica.icss.gui;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        MainGui.launch(MainGui.class,args);
    }
}
